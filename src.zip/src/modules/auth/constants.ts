export const jwtConstants = {
  secret: 'hhhhhhhhhysssssssssssssssssss324asfdsafdsfdshj32kj4h32jkhbjkas',
};
