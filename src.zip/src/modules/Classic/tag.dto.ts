export class TagDto {
  tagId: string;
  title: string;
  content: string;
  status: string;
}

export class LabelDto {
  labelId: string;
  title: string;
  content: string;
  status: string;
}